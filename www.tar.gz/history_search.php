<?php 
require 'mysql.class.php';
require 'funcs.inc.php';
if(!isset($_POST['d']) || $_POST['d'] == ''){
	SendJSON(-1, '非法请求!');
}
$range = $_POST['d'];
// $range = '04/13/2016 - 05/14/2016';

//解析查询的时间范围
$start = explode(' - ', $range);

$end = $start[1];
$start = $start[0];

$start = explode('/', $start);
$s = $start[2].'-'.$start[0].'-'.$start[1];
//获得开始的秒数
$s = strtotime($s);

$end = explode('/', $end);
$e = $end[2].'-'.$end[0].'-'.$end[1];
//获取结束的秒数,注意需要延迟一天才能采集到当天的数据
$e = strtotime($e) + 3600*24;

try{
	$db = new mysqlpdo($dbinfo);
	$sql = "select * from data where time between $s and $e order by time";
	// var_dump($sql);
	$r = $db->query($sql)->fetchAll();
	// var_dump($r);
}
catch(PDOException $e){
	SendJSON(-1, $e->getMessage());
}
$v = array();
$u = array();
$t = array();
foreach ($r as $key => $value) {

	array_push($v, intval($value['v']));
	array_push($u, intval($value['u']));
	array_push($t, date("Y-m-d H:i", $value['time']));
}

SendJSON(0, $v, $u, $t);

 ?>

