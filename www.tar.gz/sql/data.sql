drop table if exists data;
create table `data`(
    `id` int(12) NOT NULL auto_increment,
    `v` int(8) default NULL COMMENT '视频数量',
    `u` int(8) default NULL COMMENT '用户数量',
    `time` int(11) default NULL COMMENT '采集时间',
    primary key(`id`)
)engine=MyISAM default charset=utf8;
