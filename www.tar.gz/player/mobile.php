<?php
include(dirname(__FILE__).'/'."reply.inc.php");
include(dirname(__FILE__).'/'."const.php");
$height = 480;
$width = 640;
$num = 'hls';
if(isset($_GET["h"])){
    $height = @$_GET["h"];
}

if(isset($_GET["w"])){
    $width = @$_GET["w"];
}

if(isset($_GET["id"])){
    $num = @$_GET["id"];
}
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title>计算机学院2016年毕业典礼直播</title>	

    <script src="./lib/jquery.js"></script>	
    <script src="./lib/video.js"></script>	
    <script src="./js/frm.js"></script>	
    <script src="./lib/mediaelement-and-player.min.js"></script>
    <link rel="stylesheet" href="./lib/mediaelementplayer.min.css" />
    <link rel="stylesheet" href="./lib/buttons.css" />
    <link rel="stylesheet" href="./lib/video-js.css" />
<link rel="stylesheet" href="./lib/mobile_style.css">
<link rel="stylesheet" href="./lib/mobile_bootstrap.css">

<style type="text/css"> 
html { 
background-color: #EEEEEE; 
}

video {
max-width: 100%;
height: auto;
}
</style>

</head>
<body>

<input id="width" value=<?php echo $width;?> type="hidden">
<input id="height" value=<?php echo $height;?> type="hidden">
<input id="rat" value=<?php echo $width/$height;?> type="hidden">


<?php
//默认的播放源
$src = "http://".SERVERIP."/hls/".$num.".m3u8";
?>

<!--*****video标签*******-->
<div id="hls">
<video width=<?php echo $width; ?> height=<?php echo $height; ?>  id="hlsplayer"  preload="auto" autoplay="true" >
    <source type="application/x-mpegURL" src=<?php echo $src;?> id="srchls" />
    <p>To view this video please enable JavaScript, and consider upgrading to a web browser that supports HTML5 video</p>
</video>
</div>

<!--*******自定义播放*******-->
<input id="serverip" value=<?php echo SERVERIP;?> type="hidden">
<input id="src" value=<?php echo $src;?> type="hidden">
</center>

<br />

<!--******评论内容******-->
<div id="reply_content">

<div class="usermailcontainer">
<div class="usermailcontainer" style="overflow-y:scroll;overflow-x:hidden;">
            <div style="min-height:100%;border: 1px solid #BDCAD8;border-radius:4px;">

        <div class="user-vote-comment" style="border: 1px solid #BDCAD8;border-radius:4px;min-height:80%;margin:4px;overflow:hidden">

<!--参与评论-->
<!--
        <form name="frmreply" style="margin:0px">
                <div class="vote-comment-txt">
                            <div class="col-xs-12" style="padding: 10px 20px;border-top: 1px solid #ddd;background-color: #f9f9f9;">
                                <div class="col-xs-10">

                                <textarea name="reply" id="reply" placeholder="请输入评论内容" style="resize:none;width: 100%;height:60px;font-size:14px;padding:3px;border-radius:5px;"></textarea>

                                <div class="text-center">
                                <input name="replyorigin"  type="hidden" value='1' id="replyorigin" />

                                </div>
                                </div>
                                <div class="col-xs-2" style="padding:0;margin:0;">
                                        <input type="button" value="评论" class="btn btn-info" id="replybtn" name="replybtn" />
                                </div>
                            </div>
                </div>
        </form>
        -->
<div id="replys">
<h3 style='center'>点击上方空白处加载播放器</h3>
<?php
//显示已有的评论
//link_data();
//display_tree(1,0); 
?>
</div>

</div>


</div>
</div>

<div>


<script type="text/javascript">
/******更改视频源*******/
function changevideo(){
    src = $('#videoID').val();
    if(src == ''){
        alert("请输入视频流名称！");
        return;
    }
    serverip = $('#serverip').attr("value");
    $('#srchls').attr("src", "http://"+serverip+"/hls/"+src+".m3u8");
    $('#src').attr("value", "http://"+serverip+"/hls/"+src+".m3u8");
    flushhls();
}
</script>

<script type="text/javascript">
function text_click(id){
    if(document.getElementById('text'+id).style.display=="block"){
        document.getElementById('text'+id).style.display="none"; 
        document.getElementById('button'+id).style.display="none"; 
        document.getElementById('reply-in-reply'+id).style.display="none"; 
        document.getElementById('hf'+id).value="回复"; 
        }else{
            document.getElementById('reply-in-reply'+id).style.display="block"; 
            document.getElementById('text'+id).style.display="block";
            document.getElementById('button'+id).style.display="block"; 
            document.getElementById('hf'+id).value="隐藏"; 
        }
    }	
</script>




<script>
/*
    检测浏览器是否支持HTML5.0技术
 */

function checkVideo() {
    if (!!document.createElement('video').canPlayType) {
        var vidTest = document.createElement("video");
        oggTest = vidTest.canPlayType('video/ogg; codecs="theora, vorbis"');
        if (!oggTest) {
            h264Test = vidTest.canPlayType('video/mp4; codecs="avc1.42E01E, mp4a.40.2"');
            if (!h264Test) {
                return false;
}
else {
    if (h264Test == "probably") {
        return true;
}
else {
    return false;
}
}
}
else {
    if (oggTest == "probably") {
        return true;
}
else {
    return false;
}
}
}
else {
    return false;
}
}
window.onload = function(){
    if(checkVideo()){
}else{
    alert("该浏览器不支持HTML5.0,请更换支持HTML5.0的浏览器!");
    exit;
}
}
</script>



<script>

/*********定时更新回复内容**********/
//function flushreply(){
//    $('#replys').load("/player/flushreply.php",{"resultType": "html"});
//    }
//self.setInterval(flushreply, 20000);
</script>


<script>
/********加载hls视频资源*********/
function loadhls(){
    $('video').mediaelementplayer({
        // if the <video width> is not specified, this is the default
defaultVideoWidth: 480,
    // if the <video height> is not specified, this is the default
defaultVideoHeight: 270,
    // if set, overrides <video width>
    //videoWidth: size["w"]-120,
    // videoWidth: 640,
    // if set, overrides <video height>
    // videoHeight: 480,
    //videoHeight: size["h"]-100,
    // width of audio player
    audioWidth: 400,
        // height of audio player
        audioHeight: 30,
        // initial volume when the player starts
        startVolume: 1,
        // useful for <audio> player loops
        loop: false,
        // enables Flash and Silverlight to resize to content size
        enableAutosize: true,
        // the order of controls you want on the control bar (and other plugins below)
        //    features: ['playpause','progress','current','duration','tracks','volume','fullscreen'],
        features: ['volume'],
        // Hide controls when playing and mouse is not over the video
        alwaysShowControls: true,
        // force iPad's native controls
        iPadUseNativeControls: true,
        // force iPhone's native controls
        iPhoneUseNativeControls: true, 
        // force Android's native controls
        AndroidUseNativeControls: true,
        // forces the hour marker (##:00:00)
        alwaysShowHours: true,
        // show framecount in timecode (##:00:00:00)
        showTimecodeFrameCount: false,
        // used when showTimecodeFrameCount is set to true
        //   framesPerSecond: 25,
        // turns keyboard support on and off for this instance
        enableKeyboard: true,
        // when this player starts, it will pause other players
        pauseOtherPlayers: true,
        // array of keyboard commands
        keyActions: []

});
}

/*******load页面时开始加载******/
loadhls();

</script>

</body>
</html>
