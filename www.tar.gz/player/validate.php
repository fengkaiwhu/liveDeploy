<?php
require("./const.php");


if(!isset($_POST["passwd"])){
        exit;
}
$passwd = $_POST["passwd"];
if($passwd != PASSWORD){
        SendJSON(1, "密码错误,请重新输入!");
}else{
        SendJSON(0, "即将跳转到播放界面!");
}
?>
