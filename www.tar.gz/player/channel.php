<?php
include("const.php");

$height = 480;
$width = 640;
$num = 'hls';
if(isset($_GET["h"]) && $_GET["h"] != ''){
    $height = @$_GET["h"];
}

if(isset($_GET["w"]) && $_GET["w"] != ''){
    $width = @$_GET["w"];
}

if(isset($_GET["id"]) && $_GET["id"] != ''){
    $num = @$_GET["id"];
}

?>
<?php
$ua = $_SERVER['HTTP_USER_AGENT'];

if(preg_match('(iphone|ipad)', strtolower($ua))){
    header("Location:http://".SERVERIP."/player/mobile.php?h=".$height."&w=".$width."&id=".$num);
    //header("Location:http://".SERVERIP."/hls/".$num.".m3u8");
    exit;
}

if(!is_mobile()){
    //echo "PC access!";
    //PC端访问
    header("Location:http://".SERVERIP."/player/pc.php?h=".$height."&w=".$width."&id=".$num);
    exit;
}

//移动端访问控制

$qqbrowser = "MQQBrowser";
$qqweixin = "(MicroMessenger|QQ\/)";

$ten = preg_match($qqweixin, $ua);
$browser =  strpos($ua, $qqbrowser);
if($ten && $browser){
    //使用QQ微信访问，并且使用X5内核
    header("Location:http://".SERVERIP."/player/mobile.php?h=".$height."&w=".$width."&id=".$num);
    exit;

}
 
if($ten && !$browser){
    
    //使用QQ微信访问，但是没有使用X5内核
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
</head>
<body>
<font size="6">当前界面并不支持此直播视频的播放，请<a href='http://<?php echo SERVERIP;?>/player/file/MQQBrowser.apk'>点击下载</a>并安装QQ浏览器，刷新此界面即可！</font>
</body>
<?php
    exit;

}

//默认播放界面
header("Location:http://".SERVERIP."/player/mobile.php?h=".$height."&w=".$width."&id=".$num);

?>
