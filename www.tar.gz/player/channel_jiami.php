<?php
include("const.php");

$height = 480;
$width = 640;
$num = 'hls';
if(isset($_GET["h"]) && $_GET["h"] != ''){
    $height = @$_GET["h"];
}

if(isset($_GET["w"]) && $_GET["w"] != ''){
    $width = @$_GET["w"];
}

if(isset($_GET["id"]) && $_GET["id"] != ''){
    $num = @$_GET["id"];
}

if(isset($_POST["passwd"])){
        $passwd = $_POST["passwd"].trim();
        if($passwd != PASSWORD){
                alert("密码错误!");
        }
}

?>

<html>
<head>
   <title></title>
   <meta name="viewport" id="viewport" content="width=device-width, initial-scale=1">
   <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>

      <link rel="stylesheet" href="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap.min.css">
      <script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js"></script>
      <script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/js/bootstrap.min.js"></script>
      <script src="/player/js/validate.js"></script>
</head>
       <body>
       <div class="panel panel-info">
<div class="panel-heading">
<h5 class="panel-title" style="text-align:center;">请输入密码进行验证</h5>
</div>
<div class="panel-body">


       <form id="formid" method=POST action="/player/channel_jiami.php" enctype="multipart/form-data">
        <div class="container">
         <div class="row">
         <div class="col-xs-8 col-sm-8 col-md-4 col-lg-4 col-md-offset-4">
          <div class="form-group">
                               <input type="password" class="form-control" id="passwd" name="passwd" 
                                           placeholder="请输入密码进行观看">
                               <input type="hidden" id="num" name="num" value=<?php echo $num;?>>
                               <input type="hidden" id="width" name="width" value=<?php echo $width;?>>
                               <input type="hidden" id="height" name="height" value=<?php echo $height;?>>
                                                    </div></div></div>
          <div class="row">
         <div class="col-xs-8 col-sm-8 col-md-4 col-lg-4 col-md-offset-4">
                 <div class="alert alert-warning" id="info" style="text-align:center;">欢迎使用本视频直播系统<div>
         </div>
          </div>


         <div class="row">
         <div class="col-xs-8 col-sm-8 col-md-4 col-lg-4 col-md-offset-4">
                                                                                                                                                                               <div class="form-group">
                                                                                                                                                                                     <button type="button" name="btn" id="btn" class="btn btn-default">确定</button>
                                                                                                                                                                                                       </div></div></div>
                                                                                                                                                                          </div>
                                                                                                                                                                                                       </form>
                                                                                                                                                                                                       </div>
     </div>  </body>
</html>

<?php
exit;
$ua = $_SERVER['HTTP_USER_AGENT'];

if(preg_match('(iphone|ipad)', strtolower($ua))){
    header("Location:http://".SERVERIP."/hls/".$num.".m3u8");
    exit;
}

if(!is_mobile()){
    //echo "PC access!";
    //PC端访问
    header("Location:http://".SERVERIP."/player/pc.php?h=".$height."&w=".$width."&id=".$num);
    exit;
}

//移动端访问控制

$qqbrowser = "MQQBrowser";
$qqweixin = "(MicroMessenger|QQ\/)";

$ten = preg_match($qqweixin, $ua);
$browser =  strpos($ua, $qqbrowser);
if($ten && $browser){
    //使用QQ微信访问，并且使用X5内核
    header("Location:http://".SERVERIP."/player/mobile.php?h=".$height."&w=".$width."&id=".$num);
    exit;

}
 
if($ten && !$browser){
    
    //使用QQ微信访问，但是没有使用X5内核
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
</head>
<body>
<font size="6">当前界面并不支持此直播视频的播放，请<a href='http://<?php echo SERVERIP;?>/player/file/MQQBrowser.apk'>点击下载</a>并安装QQ浏览器，刷新此界面即可！</font>
</body>
<?php
    exit;

}

//默认播放界面
header("Location:http://".SERVERIP."/player/mobile.php?h=".$height."&w=".$width."&id=".$num);

?>
