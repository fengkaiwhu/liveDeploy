$(function(){
        $("#passwd").blur(function(){
                var value = $(this).val().trim();
                if(value === ''){
                        $("#info").html("请输入密码!");
                }
        });
        $("#btn").on("click", function(){
                var passwd = $("#passwd").val().trim();
                if(passwd === ''){
                        $("#info").html("请输入密码!");
                        return;
                }
                var num = $("#num").val();
                var width = $("#width").val();
                var height = $("#height").val();

                var formelement = document.getElementById("formid");
                var postdata = new FormData(formelement);
                var url = "/player/validate.php";
                var xhr = new XMLHttpRequest();
                xhr.open("POST", url, true);
                xhr.send(postdata);
                $("#info").html("正在提交请求,请稍等!");

                xhr.onload = function(e){
                        if(this.status === 200){
                                eval("var data = "+this.responseText);
                                if(data.status === 0){
                                        $("#info").html(data.text);
                                        window.open("/player/channel.php?height="+height+"&width="+width+"&num="+num, "_self");
                                }else{
                                        $("#info").html(data.text);
                                }
                        }else{
                                alert("ERROR!");
                        }
                };
        });
});
