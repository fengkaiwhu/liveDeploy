$(function(){

//	function flushreply(){
  //             $('#replys').load("/player/flushreply.php",{"resultType": "html"});
//	}
	
//	window.setInterval(alert("test"), 1500);
	
    $('#replybtn').on('click',function(event){
        var content = $('#reply').val();
        if(content == ''){
            alert('内容不能为空!');
            return;
        }

        $.ajax({type:'post', url:'/player/doreply.php', data:{content:content}, dataType:'json',
               success:function(result){
                   if(result.status == 'SUCCESS'){
                       alert('评论成功!谢谢您的参与!');
                       $('#reply').val("");
//                       $('#replys').load("/player/flushreply.php",{"resultType": "html"});

             $('<div class=\'col-xs-12 vote-comment-items\' style=\'padding: 10px 0 5px;margin: 0 20px;border-bottom: 1px solid #BDCAD8;min-height:30px;\'><div class=\'vote-commet-cell col-xs-8\' style=\'padding-left:0;\'><div class=\'vote-comment-id\' style=\'margin-bottom: 5px;display:inline;\'></div><div class=\'vote-comment-content\' style=\'margin-bottom: 5px;display:inline;\'>&nbsp' +result.content+'<div class=\'vote-comment-time\' style=\'color:#999;\'>时间：' + result.reply_time + '  来源：'+result.ip +'</div></div></div><br />').prependTo("#replys");
                   }else{
                       alert(result.text);
                   }
               }
        });
    });
});
