<?php
include("const.php");

$height = 480;
$width = 640;
$num = 'hls';
if(isset($_GET["h"]) && $_GET["h"] != ''){
    $height = @$_GET["h"];
}

if(isset($_GET["w"]) && $_GET["w"] != ''){
    $width = @$_GET["w"];
}

if(isset($_GET["id"]) && $_GET["id"] != ''){
    $num = @$_GET["id"];
}

if(!is_mobile()){
    echo "PC access!";
    echo '</br>'.$_SERVER['HTTP_USER_AGENT'];
    //PC端访问
    //header("Location:http://".SERVERIP."/player/pc.php?h=".$height."&w=".$width."&id=".$num);
    exit;
}


//header("Location:http://".SERVERIP."/player/mobile.php?h=".$height."&w=".$width."&id=".$num);
//exit;

//移动端访问控制
echo "mobile access!";

echo '</br>'.$_SERVER['HTTP_USER_AGENT'];

?>
