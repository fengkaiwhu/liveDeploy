<?php
include("const.php");

$height = 480;
$width = 640;
$num = 'hls';
if(isset($_GET["h"]) && $_GET["h"] != ''){
    $height = @$_GET["h"];
}

if(isset($_GET["w"]) && $_GET["w"] != ''){
    $width = @$_GET["w"];
}

if(isset($_GET["id"]) && $_GET["id"] != ''){
    $num = @$_GET["id"];
}

if(!is_mobile()){
    //echo "PC access!";
    //PC端访问
    header("Location:http://".SERVERIP."/player/pc.php?h=".$height."&w=".$width."&id=".$num);
    exit;
}

//移动端访问控制
$ua = $_SERVER['HTTP_USER_AGENT'];
$qqbrowser = "MQQBrowser";
$qqweixin = "(MicroMessenger|QQ\/)";

$ten = preg_match($qqweixin, $ua);
$browser =  strpos($ua, $qqbrowser);

if($ten && $browser){
    //使用QQ微信访问，并且使用X5内核
    header("Location:http://".SERVERIP."/player/mobile.php?h=".$height."&w=".$width."&id=".$num);
    exit;

}
 
if($ten && !$browser){
    //使用QQ微信访问，但是没有使用X5内核
    echo "当前界面并不支持此直播视频的播放，请"."<a href='http://".SERVERIP."/player/file/MQQBrowser.apk'>"."点击下载"."</a>"."并安装QQ浏览器，刷新此界面即可！！";
    exit;

}

//默认播放界面
header("Location:http://".SERVERIP."/player/mobile.php?h=".$height."&w=".$width."&id=".$num);

?>
