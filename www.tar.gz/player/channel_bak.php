<?php
include(dirname(__FILE__).'/'."reply.inc.php");
include(dirname(__FILE__).'/'."const.php");
$height = 480;
$width = 640;
$num = 'hls';
if(isset($_GET["h"])){
    $height = @$_GET["h"];
}

if(isset($_GET["w"])){
    $width = @$_GET["w"];
}

if(isset($_GET["id"])){
    $num = @$_GET["id"];
}
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>视频直播测试</title>	

    <script src="./lib/jquery.js"></script>	
    <script src="./lib/video.js"></script>	
    <script src="./js/frm.js"></script>	
    <script src="./lib/mediaelement-and-player.min.js"></script>
    <link rel="stylesheet" href="./lib/mediaelementplayer.min.css" />
    <link rel="stylesheet" href="./lib/buttons.css" />
    <link rel="stylesheet" href="./lib/video-js.css" />
<link rel="stylesheet" href="./lib/style.css">
<link rel="stylesheet" href="./lib/bootstrap.css">
<style type="text/css"> 
html { 
background-color: #EEEEEE; 
}
</style>
</head>
<body onkeydown="ESCkeyPress(event)">

<input id="width" value=<?php echo $width;?> type="hidden">
<input id="height" value=<?php echo $height;?> type="hidden">
<input id="rat" value=<?php echo $width/$height;?> type="hidden">

<!--****背景图片****-->
<div id="Layer1" style="position:absolute; width:99%; height:98%;z-index:0">    
<img src="lib/bg.jpg" height="100%" width="100%"/>  
</div>
<center>

<div id="nullcontent">
<br /><br /><br /><br /><br />
</div>

<?php
//默认的播放源
$src = "http://".SERVERIP."/hls/".$num.".m3u8";
?>
<!--*****video标签*******-->
<div id="hls">
<video width=<?php echo $width; ?> height=<?php echo $height; ?> id="hlsplayer"  preload="auto" autoplay="true" poster="./lib/1.jpg" >
    <source type="application/x-mpegURL" src=<?php echo $src;?> id="srchls" />
    <p>To view this video please enable JavaScript, and consider upgrading to a web browser that supports HTML5 video</p>
</video>
</div>
<div id="nullcontent2">
<br /><br />
</div>

<!--*******自定义播放*******-->
<input id="serverip" value=<?php echo SERVERIP;?> type="hidden">
<input id="src" value=<?php echo $src;?> type="hidden">
<div id="person">
<!--
<input id="videoID" value="hls" size="10" style="position:absolute;z-index:1;top:92%;left:44%">
<input type="button" id="changevideo" onclick="changevideo()" style="position:absolute;z-index:1;top:91%;left:53%" class="button blue" value="点击加载">
-->
</div>


<!--******控制按钮******-->
<div id="control">
</div>
<!--
<input type="button" id="pause" onclick="pausevideo()" class="button blue" value="暂停">
<input type="button" id="play" onclick="playvideo()" class="button blue" value="播放" disabled="true">
<input type="button" id="flush" onclick="flushhls()" class="button blue" value="刷新">
<input type="button" id="full" onclick="fullScreen()" class="button blue" value="全屏">
<input type="button" id="exitfull" onclick="exit()" class="button blue" value="退出全屏" disabled="true">
-->
</center>

<br /><br />

<!--******评论内容******-->
<div id="reply_content">

<div class="usermailcontainer">
<div class="usermailcontainer" style="overflow-y:scroll;overflow-x:hidden;">
            <div style="min-height:100%;border: 1px solid #BDCAD8;border-radius:4px;">

        <div class="user-vote-comment" style="border: 1px solid #BDCAD8;border-radius:4px;min-height:80%;margin:4px;overflow:hidden">

<!--参与评论-->
        <form name="frmreply" style="margin:0px">
                <div class="vote-comment-txt">
                            <div class="col-xs-12" style="padding: 10px 20px;border-top: 1px solid #ddd;background-color: #f9f9f9;">
                                <div class="col-xs-10">

                                <textarea name="reply" id="reply" placeholder="请输入评论内容" style="resize:none;width: 100%;height:60px;font-size:14px;padding:3px;border-radius:5px;"></textarea>

                                <div class="text-center">
                                <input name="replyorigin"  type="hidden" value='1' id="replyorigin" />

                                </div>
                                </div>
                                <div class="col-xs-2" style="padding:0;margin:0;">
                                        <input type="button" value="评论" class="btn btn-info" id="replybtn" name="replybtn" />
                                </div>
                            </div>
                </div>
        </form>
<div id="replys">
<?php
//显示已有的评论
link_data();
display_tree(1,0); 
?>
</div>
        </div>


</div>
</div>

<div>


<script type="text/javascript">
/*********流的刷新********/
function flushhls(){
    src = $('#src').attr('value');
    height = $('#height').attr('value');
    width = $('#width').attr('value');
    $('#hls').html("<video width="+width+"  height="+height+" id=\"hlsplayer\"  preload=\"auto\" autoplay=\"true\" poster=\".\/lib\/1.jpg\" >   <source type=\"application\/x-mpegURL\" src="+src+"/> <p>To view this video please enable JavaScript, and consider upgrading to a web browser that supports HTML5 video</p></video>");
    loadhls();
    //exit();
}

/*******全屏下的刷新***********/
function flushfull(){
    src = $('#src').attr('value');
    rat = $('#rat').attr('value');
    $('#hls').html("<video width="+screen.height*rat+"  height="+screen.height+" id=\"hlsplayer\"  preload=\"auto\" autoplay=\"true\" poster=\".\/lib\/1.jpg\" >   <source type=\"application\/x-mpegURL\" src="+src+"/> <p>To view this video please enable JavaScript, and consider upgrading to a web browser that supports HTML5 video</p></video>");
    loadhls();	
}

/*******视频播放********/
function pausevideo() {
    $('video')[0].player.pause();
    $('#pause').attr('disabled',"true");
    $('#play').removeAttr('disabled');

}

/*******视频暂停********/
function playvideo() {
    $('video')[0].player.play();
    $('#play').attr('disabled',"true");
    $('#pause').removeAttr('disabled');
}

/******更改视频源*******/
function changevideo(){
    src = $('#videoID').val();
    if(src == ''){
        alert("请输入视频流名称！");
        return;
    }
    serverip = $('#serverip').attr("value");
    $('#srchls').attr("src", "http://"+serverip+"/hls/"+src+".m3u8");
    $('#src').attr("value", "http://"+serverip+"/hls/"+src+".m3u8");
    flushhls();
}


/*********全屏播放*********/
function launchFullScreen() {
    element = document.documentElement;
    if(element.requestFullscreen) {
        element.requestFullscreen();
  } else if(element.mozRequestFullScreen) {
      element.mozRequestFullScreen();
  } else if(element.webkitRequestFullscreen) {
      element.webkitRequestFullscreen();
  } else if(element.msRequestFullscreen) {
      element.msRequestFullscreen();
  }
}

/***********退出全屏*********/
function exitFullScreen() {
    if(document.exitFullscreen) {
        document.exitFullscreen();
  } else if(document.mozCancelFullScreen) {
      document.mozCancelFullScreen();
  } else if(document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
  }
}

function getViewSize() {
    return {
        "w": window['innerWidth'] || document.documentElement.clientWidth,
            "h": window['innerHeight'] || document.documentElement.clientHeight
    }
}

function getFullSize() {
    var w = Math.max(document.documentElement.clientWidth, document.body.clientWidth) +

        Math.max(document.documentElement.scrollLeft, document.body.scrollLeft);
    var h = Math.max(document.documentElement.clientHeight, document.body.clientHeight) +

        Math.max(document.documentElement.scrollTop, document.body.scrollTop);
    w = Math.max(document.documentElement.scrollWidth, w);
    h = Math.max(document.documentElement.scrollHeight, h);
    return {
        "w": w,
            "h": h
    };
}

/***********开始全屏播放************/
function fullScreen(){
    src = $('#src').attr('value');
    rat = $('#rat').attr('value');
    //	size = getViewSize();
    $('#nullcontent').html('');
    $('#person').html('');
    $('#nullcontent2').html('');
    $('#control').html("<input type=\"button\" id=\"pause\" onclick=\"pausevideo()\" class=\"button blue\" value=\"暂停\"><input type=\"button\" id=\"play\" onclick=\"playvideo()\" class=\"button blue\" value=\"播放\" disabled=\"true\"><input type=\"button\" id=\"flush\" onclick=\"flushfull()\" class=\"button blue\" value=\"刷新\"><input type=\"button\" id=\"full\" onclick=\"fullScreen()\" class=\"button blue\" value=\"全屏\"><input type=\"button\" id=\"exitfull\" onclick=\"exit()\" class=\"button blue\" value=\"退出全屏\" disabled=\"true\">");
    $('#hls').html("<video width="+screen.height*rat+"  height="+screen.height+" id=\"hlsplayer\"  preload=\"auto\" autoplay=\"true\" poster=\".\/lib\/1.jpg\" >   <source type=\"application\/x-mpegURL\" src="+src+"/> <p>To view this video please enable JavaScript, and consider upgrading to a web browser that supports HTML5 video</p></video>");
    launchFullScreen();
    $('#full').attr('disabled',"true");
    $('#exitfull').removeAttr('disabled');
    loadhls();
}

/***********退出全屏播放************/
function exit(){
    src = $('#src').attr('value');
    height = $('#height').attr('value');
    width = $('#width').attr('value');
    exitFullScreen();
    $('#nullcontent').html('<br /><br /><br /><br /><br />');
    $('#nullcontent2').html('<br /><br />');
    //    $('#person').html("<input id=\"videoID\" value=\"hls\" style=\"position:absolute;z-index:1;top:92%;left:44%\" size=\"10\"><input type=\"button\" id=\"changevideo\" style=\"position:absolute;z-index:1;top:91%;left:53%\" onclick=\"changevideo()\" class=\"button blue\" value=\"点击加载\">");
    $('#control').html("<input type=\"button\" id=\"pause\" onclick=\"pausevideo()\" class=\"button blue\" value=\"暂停\"><input type=\"button\" id=\"play\" onclick=\"playvideo()\" class=\"button blue\" value=\"播放\" disabled=\"true\"><input type=\"button\" id=\"flush\" onclick=\"flushhls()\" class=\"button blue\" value=\"刷新\"><input type=\"button\" id=\"full\" onclick=\"fullScreen()\" class=\"button blue\" value=\"全屏\"><input type=\"button\" id=\"exitfull\" onclick=\"exit()\" class=\"button blue\" value=\"退出全屏\" disabled=\"true\">");
    $('#hls').html("<video width="+width+"  height="+height+" id=\"hlsplayer\"  preload=\"auto\" autoplay=\"true\" poster=\".\/lib\/1.jpg\" >   <source type=\"application\/x-mpegURL\" src="+src+"/> <p>To view this video please enable JavaScript, and consider upgrading to a web browser that supports HTML5 video</p></video>");
    $('#exitfull').attr('disabled',"true");
    $('#full').removeAttr('disabled');
    loadhls();
}

/***********esc 退出全屏播放**************/
function ESCkeyPress(event){
    return false;
    var e=window.event||event;
    var kc=e.keyCode;
    alert(kc);
    if(kc == 27){
        exit();
    }
}


</script>

<script type="text/javascript">
function text_click(id){
    if(document.getElementById('text'+id).style.display=="block"){
        document.getElementById('text'+id).style.display="none"; 
        document.getElementById('button'+id).style.display="none"; 
        document.getElementById('reply-in-reply'+id).style.display="none"; 
        document.getElementById('hf'+id).value="回复"; 
        }else{
            document.getElementById('reply-in-reply'+id).style.display="block"; 
            document.getElementById('text'+id).style.display="block";
            document.getElementById('button'+id).style.display="block"; 
            document.getElementById('hf'+id).value="隐藏"; 
        }
    }	
</script>




<script>
/*
    检测浏览器是否支持HTML5.0技术
 */

function checkVideo() {
    if (!!document.createElement('video').canPlayType) {
        var vidTest = document.createElement("video");
        oggTest = vidTest.canPlayType('video/ogg; codecs="theora, vorbis"');
        if (!oggTest) {
            h264Test = vidTest.canPlayType('video/mp4; codecs="avc1.42E01E, mp4a.40.2"');
            if (!h264Test) {
                return false;
}
else {
    if (h264Test == "probably") {
        return true;
}
else {
    return false;
}
}
}
else {
    if (oggTest == "probably") {
        return true;
}
else {
    return false;
}
}
}
else {
    return false;
}
}
window.onload = function(){
    if(checkVideo()){
}else{
    alert("该浏览器不支持HTML5.0,请更换支持HTML5.0的浏览器!");
    exit;
}
}
</script>



<script>

/* 
    Native FullScreen JavaScript API
-------------
Assumes Mozilla naming conventions instead of W3C for now
 */

(function() {
    var 
        fullScreenApi = { 
            supportsFullScreen: false,
                isFullScreen: function() { return false; }, 
                requestFullScreen: function() {}, 
                cancelFullScreen: function() {},
                fullScreenEventName: '',
                prefix: ''
        },
        browserPrefixes = 'webkit moz o ms khtml'.split(' ');

    // check for native support
    if (typeof document.cancelFullScreen != 'undefined') {
        fullScreenApi.supportsFullScreen = true;
    } else {	 
        // check for fullscreen support by vendor prefix
        for (var i = 0, il = browserPrefixes.length; i < il; i++ ) {
            fullScreenApi.prefix = browserPrefixes[i];

            if (typeof document[fullScreenApi.prefix + 'CancelFullScreen' ] != 'undefined' ) {
                fullScreenApi.supportsFullScreen = true;

                break;
            }
        }
    }

    // update methods to do something useful
    if (fullScreenApi.supportsFullScreen) {
        fullScreenApi.fullScreenEventName = fullScreenApi.prefix + 'fullscreenchange';

        fullScreenApi.isFullScreen = function() {
            switch (this.prefix) {	
            case '':
                return document.fullScreen;
            case 'webkit':
                return document.webkitIsFullScreen;
            default:
                return document[this.prefix + 'FullScreen'];
            }
        }
        fullScreenApi.requestFullScreen = function(el) {
            return (this.prefix === '') ? el.requestFullScreen() : el[this.prefix + 'RequestFullScreen']();
        }
        fullScreenApi.cancelFullScreen = function(el) {
            return (this.prefix === '') ? document.cancelFullScreen() : document[this.prefix + 'CancelFullScreen']();
        }		
    }

    // jQuery plugin
    if (typeof jQuery != 'undefined') {
        jQuery.fn.requestFullScreen = function() {

            return this.each(function() {
                var el = jQuery(this);
                if (fullScreenApi.supportsFullScreen) {
                    fullScreenApi.requestFullScreen(el);
                }
            });
        };
    }

    // export api
    window.fullScreenApi = fullScreenApi;	
})();

/**********检测用户浏览器是否支持全屏**************/
if(window.fullScreenApi.supportsFullScreen){
    $('#control').html("<input type=\"button\" id=\"pause\" onclick=\"pausevideo()\" class=\"button blue\" value=\"暂停\"><input type=\"button\" id=\"play\" onclick=\"playvideo()\" class=\"button blue\" value=\"播放\" disabled=\"true\"><input type=\"button\" id=\"flush\" onclick=\"flushhls()\" class=\"button blue\" value=\"刷新\"><input type=\"button\" id=\"full\" onclick=\"fullScreen()\" class=\"button blue\" value=\"全屏\"><input type=\"button\" id=\"exitfull\" onclick=\"exit()\" class=\"button blue\" value=\"退出全屏\" disabled=\"true\">");
}else{
    $('#control').html("<input type=\"button\" id=\"pause\" onclick=\"pausevideo()\" class=\"button blue\" value=\"暂停\"><input type=\"button\" id=\"play\" onclick=\"playvideo()\" class=\"button blue\" value=\"播放\" disabled=\"true\"><input type=\"button\" id=\"flush\" onclick=\"flushhls()\" class=\"button blue\" value=\"刷新\">");
}


/*********定时更新回复内容**********/
function flushreply(){
    $('#replys').load("/player/flushreply.php",{"resultType": "html"});
    }
self.setInterval(flushreply, 20000);
</script>


<script>
/********加载hls视频资源*********/
function loadhls(){
    $('video').mediaelementplayer({
        // if the <video width> is not specified, this is the default
defaultVideoWidth: 480,
    // if the <video height> is not specified, this is the default
defaultVideoHeight: 270,
    // if set, overrides <video width>
    //videoWidth: size["w"]-120,
    // videoWidth: 640,
    // if set, overrides <video height>
    // videoHeight: 480,
    //videoHeight: size["h"]-100,
    // width of audio player
    audioWidth: 400,
        // height of audio player
        audioHeight: 30,
        // initial volume when the player starts
        startVolume: 1,
        // useful for <audio> player loops
        loop: false,
        // enables Flash and Silverlight to resize to content size
        enableAutosize: true,
        // the order of controls you want on the control bar (and other plugins below)
        //    features: ['playpause','progress','current','duration','tracks','volume','fullscreen'],
        features: ['volume'],
        // Hide controls when playing and mouse is not over the video
        alwaysShowControls: true,
        // force iPad's native controls
        iPadUseNativeControls: true,
        // force iPhone's native controls
        iPhoneUseNativeControls: true, 
        // force Android's native controls
        AndroidUseNativeControls: true,
        // forces the hour marker (##:00:00)
        alwaysShowHours: true,
        // show framecount in timecode (##:00:00:00)
        showTimecodeFrameCount: false,
        // used when showTimecodeFrameCount is set to true
        //   framesPerSecond: 25,
        // turns keyboard support on and off for this instance
        enableKeyboard: true,
        // when this player starts, it will pause other players
        pauseOtherPlayers: true,
        // array of keyboard commands
        keyActions: []

});
}

/*******load页面时开始加载******/
loadhls();

</script>

</body>
</html>
