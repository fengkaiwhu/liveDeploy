<?php

    function display_tree($page,$replyID) //$page 用来进行分页处理，可先不用
    {
       $sql="select * from reply where pid='".$replyID."' order by id DESC ";
       $result=mysql_query($sql);
       if(mysql_num_rows($result) == 0){
           return;
       }
		?>
		
		
		<?php
        while($row = mysql_fetch_array($result))
        {
			
             echo "<div class='col-xs-12 vote-comment-items' style='padding: 10px 0 5px;margin: 0 20px;border-bottom: 1px solid #BDCAD8;min-height:30px;'>";
			 if($replyID != 0){////replyID为0表示是一级回复，否则不是一级回复             
				echo "<div class='col-xs-1'></div>";
			
			//echo "<div class='col-xs-1' style='padding-right:0;'></div>";
			echo "<div class='vote-commet-cell col-xs-7' style='padding-left:0;'>";
		
			echo "<div class='vote-comment-id' style='margin-bottom: 5px;display:inline;'></div>";
           
		
			//	echo "<div class='vote-comment-content' style='margin-bottom: 5px;display:inline;'><span style='padding-left:10px;'></span>回复了<a href='bbsdispuser.php?id=".$row['pname']."'>".$row["pname"]."</a>:<span style='padding-left:10px;'></span>".$row["content"];
				echo "<div class='vote-comment-content' style='margin-bottom: 5px;display:inline;'><span style='padding-left:10px;'></span><span style='padding-left:10px;'></span>".$row["content"];
            }else{
				
					
		//	echo "<div class='col-xs-1' style='padding-right:0;'></div>";
			echo "<div class='vote-commet-cell col-xs-8' style='padding-left:0;'>";
		
			echo "<div class='vote-comment-id' style='margin-bottom: 5px;display:inline;'></div>";
           
				echo "<div class='vote-comment-content' style='margin-bottom: 5px;display:inline;'>&nbsp".$row["content"];
			}
            echo "<div class='vote-comment-time' style='color:#999;'>时间：".$row["reply_time"]."     来源：".$row["ip"]." </div></div>";
			
			echo "</div>";
		
			
			
	   if(1){

//		echo    "<div class='col-xs-2'><input id='hf".$row["id"]."' type='button' value='回复' onclick='text_click(".$row["id"].")' style='width:50px;height:50px;' class='btn btn-info pull-right' /></div>";
				
				
			 
?>
	<form name ="form1" method="post" action="" style="margin:0px" >	
		<input name="pid" type="hidden" id="pid" value="<?php echo $row["id"]; ?>" />
		<input name="pname" type="hidden" id="pname" value="<?php echo $row["username"]; ?>" />
		<div class="col-xs-12" id="reply-in-reply<?php echo $row["id"]; ?>" style="display:none;padding: 10px 20px;border-top: 1px solid #ddd;background-color: #f9f9f9;">
		<div class="col-xs-10">
			<textarea name="text<?php echo $row["id"]; ?>" id="text<?php echo $row["id"]; ?>"  style="display:none;resize:none;width: 100%;height:60px;font-size:12px;padding:3px;border-radius:5px;"></textarea>
		</div>
		<div class="col-xs-2" style="padding:0;margin:0;">
			<input id="button<?php echo $row["id"]; ?>" type="submit"  value='提交' class="btn btn-info" style="display:none;height: 56px;width:70px;cursor: pointer;margin:2px 0;" />
		</div>
		</div>
	</form>
<?php
	
	   }
	   echo "</div>";
        echo "<br />";
		
		
	display_tree($page,$row["id"]);
     } 
	
	?>


	<?php
	
    }
	?>

<?php
    function doreply($loginID)
    {
	    //用来处理提交评论的请求
	    if(isset($_POST["pid"])){
		    @$pid = $_POST["pid"];
		    @$pname=$_POST["pname"];
		    @$titleID = $_POST["titleid"];
		    @$content = trim($_POST["text".$pid]);
		    $currenttime = date('Y-m-d H:i:s',time());
		    if(empty($content)){
			    echo "<script language='javascript'>alert('内容不能为空！');window.history.go(-1);</script> ";
			    exit;
		    }
		    $query = "insert into reply(username,pid,pname,titleid,content,reply_time) values('".$loginID."', '".$pid."','".$pname."','".$titleID."','".$content."','".$currenttime."')";
		    $reqult = mysql_query($query);
		    echo "<script language='javascript'>alert('评论成功！'); window.location.href='bbsuser_vote.php?id='+$titleID;</script>";
		    
		
		}
    }

    function doreplyorigin($loginID)
    {
	    //用来处理提交评论的请求,回复的是主题
	    if(isset($_POST["replyorigin"])){
		   // @$pid = $_POST["pid"];
		   // @$pname=$_POST["pname"];
		    @$titleID = $_GET["id"];
		    @$content = trim($_POST["reply"]);
		    $currenttime = date('Y-m-d H:i:s',time());
		    if(empty($content)){
			    echo "<script language='javascript'>alert('内容不能为空！');window.history.go(-1);</script> ";
			    exit;
		    }
		    $query = "insert into reply(username,pid,pname,titleid,content,reply_time) values('".$loginID."', '0','','".$titleID."','".$content."','".$currenttime."')";
		    $reqult = mysql_query($query);
		    echo "<script language='javascript'>alert('评论成功！'); window.location.href='bbsuser_vote.php?id='+$titleID;</script>";
		   exit; 
		
		}
    }


?>
