<?php
function SendJSON($status,$message,$message2=''){
    $result = array("status"=>$status,"content"=>$message, "content2"=>$message2);
    echo json_encode($result);
//    echo  preg_replace("#\\\u([0-9a-f]{4})#ie", "iconv('UCS-2BE', 'UTF-8', pack('H4', '\\1'))", json_encode($result));
    exit();
}

?>
