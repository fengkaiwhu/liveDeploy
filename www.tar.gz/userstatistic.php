<?php
require 'funcs.inc.php';
require 'IP.class.php';
$r = exec('/usr/local/bin/python2.7 /home/www/hls/userstatistic.py', $out, $status);
if ($status) {
	SendJSON(-1, '执行失败,请稍后再试!');
}

$r = json_decode($r);
// $r = array("hls.m3u8"=>array('59.172.176.227', '120.198.231.24', '180.235.66.206', '221.181.206.12', '112.65.200.213', '58.246.242.154'),
// 	"1.m3u8"=>array('58.246.242.154', '112.84.133.82', '218.58.209.3'),
// 	"2.m3u8"=>array('120.198.231.24', '120.52.72.19', '175.6.10.137'),
// 	"3.m3u8"=>array('120.198.231.24'),
// 	"4.m3u8"=>array()
// 	);
// var_dump($r);

$s = array();
foreach ($r as $video => $value) {
	$f = array();
	foreach($value as $key => $ip){
		$result = IP::find($ip);
		if($result[0] == '中国'){
			//这里暂时只处理中国的IP数据,其他数据暂时不管
			if (isset($f[$result[1]])) {
				$f[$result[1]] = $f[$result[1]] + 1;
			}else{
				$f[$result[1]] = 1;
			}
		}
	}
	$s[$video] = $f;
}
$m = array('s'=>0, 'm'=>$s);
echo json_encode($m);
?>
