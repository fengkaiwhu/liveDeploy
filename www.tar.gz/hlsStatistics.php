<!DOCTYPE html>
<html>
<head>
	<title>直播系统统计概述</title>
<meta name="viewport" id="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
<script src="./js/jquery-1.8.3.min.js"></script>
<script src="./js/jquery.min.js"></script>
<link href="./bootstrap-3.3.5-dist/css/bootstrap.min.css" rel="stylesheet">
<!-- <link href="/time-picker/bootstrap-datetimepicker.min.css" rel="stylesheet">
<script src="/time-picker/bootstrap-datetimepicker.min.js"></script> -->
<script src="/time-picker/moment.min.js"></script>

<link href="/time-picker/daterangepicker.css" rel="stylesheet">
<script src="/time-picker/daterangepicker.js"></script>

<script src="./bootstrap-3.3.5-dist/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-sm-1 col-md-1 col-md-1"></div>
		<div class="col-sm-10 col-md-10 col-md-10">
			<div class="panel panel-success">
			   <div class="panel-heading">
			      <h3 class="panel-title text-center">直播系统统计结果</h3>
			   </div>
			   <div class="panel-body">
					<ul id="myTab" class="nav nav-tabs">
					   <li class="active">
					      <a href="#home" data-toggle="tab">
					         实时统计
					      </a>
					   </li>
					   <li><a href="#ios" data-toggle="tab">分布情况</a></li>
   					   <li><a href="#ejb" data-toggle="tab">历史数据</a></li>
					</ul>
					<div id="myTabContent" class="tab-content">
					   <div class="tab-pane fade in active" id="home">				   
					   		<div class="checkbox"><label><input id="main_time" type="checkbox" checked='checked'>实时更新数据</label></div>
					       <div id="main" style="height:400px"></div>
   					   		<div class="checkbox"><label><input id="user_time" type="checkbox" checked='checked'>实时更新数据</label></div>
					       <div id="user" style="height:400px"></div>
				       </div>
					   <div class="tab-pane fade" id="ios">
					   		<div class="checkbox"><label><input id="fenbu_time" type="checkbox" checked='checked'>实时更新数据</label></div>
					       <div id="fenbu_test" style="height:400px"></div>
					   </div>
					   <div class="tab-pane fade" id="ejb">

					    <div class="well">
							<div class="input-group">
								<span class="input-group-addon">查询范围</span>
					         	<input type="text" class="form-control" id="time_picker" readonly="true">
								<span class="input-group-btn">
									<button class="btn btn-default" type="button" id="submit_history">
										Go!
									</button>
               					</span>		         	
					        </div>
		    	
					    </div>
				        <div id="history_data" style="height:400px"></div>

    					<script type="text/javascript">
							function CurentTime(month_shift)
							{ //获取当前时间
							    var now = new Date();       
							    var year = now.getFullYear();       //年
							    var month = now.getMonth() + 1;     //月
							    var day = now.getDate();            //日       
							    var clock;

							    if(month_shift){
							    	if(month === 1){
							    		month = 12;
							    		year = year - 1;
							    	}else{
							    		month -= 1;
							    	}
							    }

							    if(month < 10)
							        clock += "0";
							    clock += month + "/";
							   
							    if(day < 10)
							        clock += "0";           
							    clock += day + "/";

							    clock += year;

							    return(clock); 
							} 

							$(document).ready(function() {
								// alert(CurentTime());
								// var t = new Date();
								$('#time_picker').daterangepicker({
									// format: "yyyy-MM-dd",
									// 默认开始时间为前一个月
									// dateFormat:'yy-mm-dd',
									// closeOnSelect: true,
									startDate: CurentTime(1),
									endDate: CurentTime(0),
									maxDate: CurentTime(0),
									dateLimit : {
										days: 32 //设定时间的最大间隔
									},
									// autoClose: true
								},function(start, end, label){
									
								}
								);

							});

    					</script>            

					   </div>
							      <!-- // <script src="http://echarts.baidu.com/build/dist/echarts.js"></script> -->
							      <script src="./js/echarts.js"></script>
							      <script src="./js/china.js"></script>
							      <script type="text/javascript">
							        require.config({
							            paths: {
							                // echarts: 'http://echarts.baidu.com/build/dist'
							                echarts: './js'
							            }
							        });
							        // 使用
							        require
							        (
							            [
							                'echarts',
							                'echarts/chart/line',
							                'echarts/chart/bar', // 使用柱状图就加载bar模块，按需加载
							                'echarts/chart/pie',
							                'echarts/chart/map'
							            ],
							            function (ec) 
							            {
							                // 基于准备好的dom，初始化echarts图表
							                var myChart = ec.init(document.getElementById('main')); 
                    						var userChart = ec.init(document.getElementById('user'));

							                var option = {
											    title : {
											    	x: 'center',
											        text: '实时数量统计'
											        // subtext: '纯属虚构'
											    },
											    tooltip : {
											        trigger: 'axis'
											    },
											    legend: {
											    	x: 'left',
											        data:['视频源数量', '观看人数']
											    },
											    toolbox: {
											        show : true,
											        feature : {
											            mark : {show: true},
											            dataView : {show: true, readOnly: false},
											            magicType : {show: true, type: ['line', 'bar']},
											            restore : {show: true},
											            saveAsImage : {show: true}
											        }
											    },
											    dataZoom : {
											        show : false,
											        start : 0,
											        end : 100
											    },
											    xAxis : [
											        {
											            type : 'category',
											            boundaryGap : true,
											            data : (function (){
											                var now = new Date();
											                var res = [];
											                var len = 10;
											                while (len--) {
											                    res.unshift(now.toLocaleTimeString().replace(/^\D*/,''));
											                    now = new Date(now - 2000);
											                }
											                return res;
											            })()
											        }

											    ],
											    yAxis : [
											        {
											            type : 'value',
											            scale: true,
											            name : '视频源数',
											            min: 0,
											            max:100,
											            boundaryGap: [0.2, 0.2]
											        },
											        {
											            type : 'value',
											            scale: true,
											            name : '用户数',
											            boundaryGap: [0.2, 0.2]
											        }
											    ],
											    series : [
											        {
											            name:'视频源数量',
											            type:'bar',
											            // xAxisIndex: 1,
											            yAxisIndex: 0,
											            data:[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
											        },
											        {
											            name:'观看人数',
											            type:'line',
											            yAxisIndex: 1,
											            data:[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
											        }
											    ]
											};

											var user_option = {
												    title : {
												        text: '各视频观看用户数',
												        x:'center'
												    },
												    tooltip : {
												        trigger: 'item',
												        formatter: "{a} <br/>{b} : {c} ({d}%)"
												    },
												    legend: {
												        orient : 'vertical',
												        x : 'left',
												        data:[]
												    },
												    toolbox: {
												        show : true,
												        feature : {
												            mark : {show: true},
												            dataView : {show: true, readOnly: false},
												            restore : {show: true},
												            saveAsImage : {show: true}
												        }
												    },
												    calculable : true,
												    series : [
												        {
												            name:'访问来源',
												            type:'pie',
												            radius : '55%',
												            center: ['50%', '60%'],
												            data:[
												            ]
												        }
												    ]
												};
							                myChart.setOption(option);
											userChart.setOption(user_option);
							
											// var fenbuChart = ec.init(document.getElementById('fenbu_test'));
											// fenbuChart.setOption(user_option);
                    
											var axisData;
											var timeTicket;
											var fenbuTicket;
											clearInterval(timeTicket);
											clearInterval(fenbuTicket);

											timeTicket = setInterval(function (){
												if($('#main_time').prop('checked') ||  $('#user_time').prop('checked')){
													var video_num = 0;
													var user_num = 0;
													var message;
											        $.ajax({
											            type:"POST",
											            url:"/video_num.php",
											            dataType:"json",
											            async:true,
											            data:{
											                
											            },
											            success:function(data){
											                if(data.s !== 0){
											                	alert(data.m);
											                }else{
											                	message = data.m;
			               									    for(key in data.m){
			               									    	video_num += 1;
			               									    	user_num += data.m[key];
                                                                }
                                        //模拟数据的产生
                                        //video_num = parseInt(Math.random()*20);
                                        //user_num = parseInt(Math.random()*100 + 100);

															    axisData = (new Date()).toLocaleTimeString().replace(/^\D*/,'');

															    // 动态数据接口 addData
															    if($('#main_time').prop('checked')){
																    myChart.addData([
																        [
																            0,        // 系列索引
																            video_num, // 新增数据
																            false,     // 新增数据是否从队列头部插入
																            false     // 是否增加队列长度，false则自定删除原有数据，队头插入删队尾，队尾插入删队头
																        ],
																        [
																            1,        // 系列索引
																            user_num, // 新增数据
																            false,    // 新增数据是否从队列头部插入
																            false,    // 是否增加队列长度，false则自定删除原有数据，队头插入删队尾，队尾插入删队头
																            axisData  // 坐标轴标签
																        ]
																    ]);
																}

															    if($('#user_time').prop('checked')){
																    var user_option = {
																	    title : {
																	        text: '各视频观看用户数',
																	        subtext: axisData,
																	        x:'center'
																	    },
																	    tooltip : {
																	        trigger: 'item',
																	        formatter: "{a} <br/>{b} : {c} ({d}%)"
																	    },
																	    legend: {
																	        orient : 'vertical',
																	        x : 'left',
																            data : (function (){
																                // var now = new Date();
																                var res = [];
																                // var len = message.length;
																                for(key in message){
																                	res.unshift(key);
																                }
																                // while (len--) {
																                //     res.unshift(message);
																                //     // now = new Date(now - 2000);
																                // }
																                return res;
																            })()													        
																	        // data:['直接访问','邮件营销','联盟广告','视频广告','搜索引擎']
																	    },
																	    toolbox: {
																	        show : true,
																	        feature : {
																	            mark : {show: true},
																	            dataView : {show: true, readOnly: false},
																	            restore : {show: true},
																	            saveAsImage : {show: true}
																	        }
																	    },
																	    calculable : true,
																	    series : [
																	        {
																	            name:'用户比例',
																	            type:'pie',
																	            radius : '55%',
																	            center: ['50%', '60%'],
																	            data : (function (){
																	                // var now = new Date();
																	                var res = [];
																	                // var len = message.length;
																	                for(pro in message){
																	                	var i = {
																	                		name: pro,
																	                		value: message[pro]			       
																	                	}
																	                	res.unshift(i);
																	                }
																	                return res;
																	            })()														            
																	            // data:[
																	            //     {value:335, name:'直接访问'},
																	            //     {value:310, name:'邮件营销'},
																	            //     {value:234, name:'联盟广告'},
																	            //     {value:135, name:'视频广告'},
																	            //     {value:1548, name:'搜索引擎'}
																	            // ]
																	        }
																	    ]
																	}; // option定义结束
																	var userChart = ec.init(document.getElementById('user'));
																	userChart.setOption(user_option);
																}			               									
											                }//else结束
											            },
											            error:function(){
											            	alert('请求出错,请稍后再试!');
											                // $("#information").html("请求出错,请稍后再试!");
											            },
											            beforeSend:function(){
											            }
											        });
										    	}


												
											}, 10000);//定时器结束

											fenbuTicket = setInterval(function (){
												if($('#fenbu_time').prop('checked')){
													var message;
											        $.ajax({
											            type:"POST",
											            url:"/userstatistic.php",
											            dataType:"json",
											            async:true,
											            data:{
											                
											            },
											            success:function(data){
											                if(data.s !== 0){
											                	alert(data.m);
											                }else{
											                	message = data.m;
																axisData = (new Date()).toLocaleTimeString().replace(/^\D*/,'');

				    											var fenbu_option = {
																    title : {
																        text: '用户分布',
																        subtext: axisData,
																        x:'center'
																    },
																    tooltip : {
																        trigger: 'item'
																    },
																    legend: {
																        orient: 'vertical',
																        x:'left',
															            data : (function (){
															                // var now = new Date();
															                var res = [];
															                // var len = message.length;
															                for(key in message){
															                	res.unshift(key);
															                }
															                // while (len--) {
															                //     res.unshift(message);
															                //     // now = new Date(now - 2000);
															                // }
															                return res;
															            })()
																    },
																    dataRange: {
																        min: 0,
																        max: 1500,
																        x: 'left',
																        y: 'bottom',
																        text:['高','低'],           // 文本，默认为数值文本
																        calculable : true
																    },
																    toolbox: {
																        show: true,
																        orient : 'vertical',
																        x: 'right',
																        y: 'center',
																        feature : {
																            mark : {show: true},
																            dataView : {show: true, readOnly: false},
																            restore : {show: true},
																            saveAsImage : {show: true}
																        }
																    },
																    roamController: {
																        show: true,
																        x: 'right',
																        mapTypeControl: {
																            'china': true
																        }
																    },
														            series : (function (){
															                // var now = new Date();
															                var res = [];
															                // var len = message.length;
															                for(key in message){
															                	var item ={
																		            name: key,
																		            type: 'map',
																		            mapType: 'china',
																		            roam: false,
																		            itemStyle:{
																		                normal:{label:{show:true}},
																		                emphasis:{label:{show:true}}
																		            },
																		            data : (function (){
																		                // var now = new Date();
																		                var res = [];
																		                // var len = message.length;
																		                for(pro in message[key]){
																		                	var i = {
																		                		name: pro,
																		                		value: message[key][pro]			       
																		                	}
																		                	res.unshift(i);
																		                }
																		                return res;
																		            })()															           
															                	}
															                	res.unshift(item);
															                }
															                return res;
														            })(),
																    
																};
																var fenbuChart = ec.init(document.getElementById('fenbu_test'));
																fenbuChart.setOption(fenbu_option);
											                }											                
											                // message = data;
											            },
											            error:function(){
											            	alert('请求出错,请稍后再试!');
											                // $("#information").html("请求出错,请稍后再试!");
											            },
											            beforeSend:function(){
											            }
											        });


											    	
												}

											}, 20000);//定时器结束

							            }//function(ec)结束
							        );
									$("#submit_history").on('click', function(){
										var d = $("#time_picker").val();
										// alert(d);
										require.config({
								            paths: {
								                // echarts: 'http://echarts.baidu.com/build/dist'
								                echarts: './js'
								            }
							        	});
							        	require
								        (
								            [
								                'echarts',
								                'echarts/chart/line',
								                'echarts/chart/bar', // 使用柱状图就加载bar模块，按需加载
								                'echarts/chart/pie',
								                'echarts/chart/map'
								            ],
								            function (ec) 
								            {

												var history_chart = ec.init(document.getElementById('history_data'));
												history_chart.showLoading({
													text: '数据正在加载中......'
												});
												var history_data_option = {
												    title : {
												    	x: 'center',
												        text: '实时数量统计'
												        // subtext: '纯属虚构'
												    },
												    tooltip : {
												        trigger: 'axis'
												    },
												    legend: {
												    	x: 'left',
												        data:['视频源数量', '观看人数']
												    },
												    toolbox: {
												        show : true,
												        feature : {
												            mark : {show: true},
												            dataView : {show: true, readOnly: false},
												            magicType : {show: true, type: ['line', 'bar']},
												            restore : {show: true},
												            saveAsImage : {show: true}
												        }
												    },
												    dataZoom : {
												        show : false,
												        start : 0,
												        end : 100
												    },
												    xAxis : [
												        {
												            type : 'category',
												            boundaryGap : true,
												            data : []
												        }

												    ],
												    yAxis : [
												        {
												            type : 'value',
												            scale: true,
												            name : '视频源数',
												            min: 0,
												            max:100,
												            boundaryGap: [0.2, 0.2]
												        },
												        {
												            type : 'value',
												            scale: true,
												            name : '用户数',
												            boundaryGap: [0.2, 0.2]
												        }
												    ],
												    series : [
												        {
												            name:'视频源数量',
												            type:'bar',
												            // xAxisIndex: 1,
												            yAxisIndex: 0,
												            data:[]
												        },
												        {
												            name:'观看人数',
												            type:'line',
												            yAxisIndex: 1,
												            data:[]
												        }
												    ]
												};
												// history_chart.setOption(history_data_option);
												$.ajax({
										            type:"POST",
										            url:"/history_search.php",
										            dataType:"json",
										            async:true,
										            data:{
										              'd': d  
										            },
										            success: function(result){
										            	if (result.s !== 0) {
										            	// if (false) {

										            		alert(result.m);
										            	}else{
										            		// message = result.m;
										            		// alert(d);
										            		
										            		history_chart.hideLoading();
															var history_data_option = {
															    title : {
															    	x: 'center',
															        text: '历史数据查询'
															        // subtext: '纯属虚构'
															    },
															    grid: {
															    	bottom: 80
															    },
															    tooltip : {
															        trigger: 'axis'
															    },
															    legend: {
															    	x: 'left',
															        data:['视频源数量', '观看人数']
															    },
															    toolbox: {
															        show : true,
															        feature : {
															            mark : {show: true},
															            dataView : {show: true, readOnly: false},
															            magicType : {show: true, type: ['line', 'bar']},
															            restore : {show: true},
															            saveAsImage : {show: true}
															        }
															    },
															    dataZoom : {
															        show : true,
															        start : 0,
															        end : 100,
															        type: 'inside'
															    },
															    calculable: true,

															    xAxis : [
															        {
															            type : 'category',
															            boundaryGap : false,
															            axisLine: {onZero: false},
															            data : result.m3.map(function(str) {
															            	return str.replace(' ', '\n')
															            })
															        }

															    ],
															    yAxis : [
															        {
															            type : 'value',
															            // scale: true,
															            name : '视频源数',
															            max: Math.max.apply(null, result.m)
															            // alert(Math.max.apply(null, result.n))
															            // min: 0,
															            // boundaryGap: [0.2, 0.2]
															        },
															        {
															            type : 'value',
															            // scale: true,
															            name : '用户数',
															            max: Math.max.apply(null, result.m2)
															            // boundaryGap: [0.2, 0.2]
															        }
															    ],
															    series : [
															        {
															            name:'视频源数量',
															            type:'line',
															            // xAxisIndex: 1,
															            yAxisIndex: 0,
															            hoverAnimation: false,
															            smooth: true,
															            itemStyle: {normal: {areaStyle : {type: 'default'}}},
															            // areaStyle: {
															            // 	normal : {}
															            // },
															            // lineStyle: {
															            // 	normal: {
															            // 		width: 1
															            // 	}
															            // },
															            data:result.m
															        },
															        {
															            name:'观看人数',
															            type:'line',
															            yAxisIndex: 1,
															            hoverAnimation: false,
															            smooth: true,
															            itemStyle: {normal: {areaStyle : {type: 'default'}}},

															            // areaStyle: {
															            // 	normal : {}
															            // },															            
															            // lineStyle: {
															            // 	normal: {
															            // 		width: 1
															            // 	}
															            // },															            
															            data:result.m2
															        }
															    ]
															};										            		
										            		history_chart.setOption(history_data_option);
										            	}
										            },
										            error: function(result){
										            	alert('数据请求出错,请稍后再试!');
										            	alert(result);
										            }

												});
											}
										);


									});
							    </script>			 
					   

					</div>
			   </div>
			</div>
			
		</div>
		<div class="col-sm-1 col-md-1 col-md-1"></div>
	</div>
</div>

</body>
</html>
