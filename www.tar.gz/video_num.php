<?php
require 'funcs.inc.php';
$r = exec('/usr/local/bin/python2.7 /home/www/hls/main.py 2>&1', $out, $status);
if ($status) {
	SendJSON(-1, '执行失败,请稍后再试!');
}

$r = json_decode($r);
// var_dump($r)
echo json_encode($r);
?>
